# WCST_HTML
Wisconsin Card Sorting Task (WCST) in HTML + JS 
